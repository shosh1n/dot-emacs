// -*- combobulate-test-point-overlays: ((1 outline 229) (2 outline 262) (3 outline 279) (4 outline 299) (5 outline 333) (6 outline 381)); eval: (combobulate-test-fixture-mode t); -*-
package main

import "fmt"

func main() {

	nums := []int{2, 2, 2, 2, 3, 4}
	sum := 0
        sum += num

        fmt.Println("sum:", sum)

        for k, v := range kvs {
		fmt.Printf("%s -> %s\n", k, v)
		// Do something with k and v
	}
	map[string]string{"a": "apple", "b": "banana"}
	
}

var (
	foo = "bar"
	baz = "qux"
)

const (
	message = "Hello, world!"
	foo     = 42
)

type Person struct {
	Name string
	Age  int
}
